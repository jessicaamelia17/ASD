public class InformasiMahasiswa {
    public String nama;
    public String nim;
    public String jenisKelamin;
    public double ipk;
}

package PRAKTIKUM10;

public class Node {
        int data;
        Node prev;
        Node next;
    
        public Node(int data){
            this.data = data;
            // this.prev = prev;
            // this.next = next;
        }
    
}

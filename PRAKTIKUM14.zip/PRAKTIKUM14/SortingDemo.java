package PRAKTIKUM14;

import java.util.ArrayList;
import java.util.Collections;
public class SortingDemo {
    public static void main(String[] args) {
        ArrayList<String> daftarSiswa = new ArrayList<>();
        daftarSiswa.add("Zainab");
        daftarSiswa.add("Andi");
        daftarSiswa.add("Rara");
        Collections.sort(daftarSiswa);

        System.out.println(daftarSiswa);

        // daftarSiswa.sort((c1,c2)->c1.e.compareTo(c2.e));
        // System.out.println(daftarSiswa);
    }
}
